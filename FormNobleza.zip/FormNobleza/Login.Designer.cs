﻿namespace FormNobleza
{
    partial class FormLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCorreo = new TextBox();
            txtContraseña = new TextBox();
            btnSesion = new Button();
            panel1 = new Panel();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Font = new Font("Segoe UI Semibold", 18F);
            label1.ForeColor = Color.FromArgb(26, 26, 26);
            label1.Location = new Point(428, 24);
            label1.Name = "label1";
            label1.Size = new Size(210, 32);
            label1.TabIndex = 0;
            label1.Text = "INICIO DE SESIÓN";
            label1.Click += label1_Click;
            // 
            // txtCorreo
            // 
            txtCorreo.BorderStyle = BorderStyle.None;
            txtCorreo.Font = new Font("Segoe UI Semibold", 12F);
            txtCorreo.Location = new Point(381, 122);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(200, 22);
            txtCorreo.TabIndex = 3;
            txtCorreo.Text = "Usuario:";
            // 
            // txtContraseña
            // 
            txtContraseña.BorderStyle = BorderStyle.None;
            txtContraseña.Font = new Font("Segoe UI Semibold", 12F);
            txtContraseña.Location = new Point(381, 170);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.Size = new Size(200, 22);
            txtContraseña.TabIndex = 4;
            txtContraseña.Text = "Contraseña:";
            // 
            // btnSesion
            // 
            btnSesion.BackColor = Color.FromArgb(25, 118, 210);
            btnSesion.Cursor = Cursors.Hand;
            btnSesion.FlatAppearance.BorderSize = 0;
            btnSesion.FlatStyle = FlatStyle.Flat;
            btnSesion.Font = new Font("Segoe UI Semibold", 12F);
            btnSesion.ForeColor = Color.FromArgb(248, 249, 250);
            btnSesion.Location = new Point(381, 215);
            btnSesion.Name = "btnSesion";
            btnSesion.Size = new Size(200, 30);
            btnSesion.TabIndex = 5;
            btnSesion.Text = "Iniciar Sesión";
            btnSesion.UseVisualStyleBackColor = false;
            btnSesion.Click += button1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnSesion);
            panel1.Controls.Add(txtCorreo);
            panel1.Controls.Add(txtContraseña);
            panel1.Location = new Point(183, 58);
            panel1.Name = "panel1";
            panel1.Size = new Size(770, 415);
            panel1.TabIndex = 8;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(0, 115, 138);
            panel3.Location = new Point(183, 58);
            panel3.Name = "panel3";
            panel3.Size = new Size(248, 412);
            panel3.TabIndex = 8;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Excel2__1_1;
            pictureBox1.Location = new Point(244, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 81);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(984, 541);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Name = "FormLogin";
            Text = "Form Login";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox txtCorreo;
        private TextBox txtContraseña;
        private Button btnSesion;
        private Panel panel1;
        private Panel panel3;
        private PictureBox pictureBox1;
    }
}
