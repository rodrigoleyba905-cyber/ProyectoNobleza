﻿namespace FormNobleza
{
    partial class Tracking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tracking));
            label4 = new Label();
            label5 = new Label();
            btnGuardarMovimiento = new Button();
            txtId = new TextBox();
            txtUbicacion = new ComboBox();
            txtComentarios = new TextBox();
            txtEncargado = new TextBox();
            label7 = new Label();
            dataGridView1 = new DataGridView();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            pctureLogo = new PictureBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            label1 = new Label();
            button1 = new Button();
            panel5 = new Panel();
            label11 = new Label();
            btnProfil = new Button();
            btnExit = new Button();
            btnTracking = new Button();
            btnCrud = new Button();
            btnHome = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pctureLogo).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(95, 323);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(380, 387);
            label5.Name = "label5";
            label5.Size = new Size(0, 15);
            label5.TabIndex = 4;
            // 
            // btnGuardarMovimiento
            // 
            btnGuardarMovimiento.BackColor = Color.FromArgb(0, 115, 138);
            btnGuardarMovimiento.Cursor = Cursors.Hand;
            btnGuardarMovimiento.FlatAppearance.BorderSize = 0;
            btnGuardarMovimiento.FlatStyle = FlatStyle.Flat;
            btnGuardarMovimiento.Font = new Font("Segoe UI Semibold", 12F);
            btnGuardarMovimiento.ForeColor = Color.FromArgb(248, 249, 250);
            btnGuardarMovimiento.Location = new Point(41, 289);
            btnGuardarMovimiento.Name = "btnGuardarMovimiento";
            btnGuardarMovimiento.Size = new Size(209, 29);
            btnGuardarMovimiento.TabIndex = 5;
            btnGuardarMovimiento.Text = "Guardar";
            btnGuardarMovimiento.UseVisualStyleBackColor = false;
            // 
            // txtId
            // 
            txtId.Font = new Font("Segoe UI Semibold", 12F);
            txtId.Location = new Point(41, 87);
            txtId.Name = "txtId";
            txtId.Size = new Size(209, 29);
            txtId.TabIndex = 6;
            txtId.Text = "Id";
            // 
            // txtUbicacion
            // 
            txtUbicacion.Font = new Font("Segoe UI Semibold", 12F);
            txtUbicacion.FormattingEnabled = true;
            txtUbicacion.Location = new Point(41, 172);
            txtUbicacion.Name = "txtUbicacion";
            txtUbicacion.Size = new Size(209, 29);
            txtUbicacion.TabIndex = 7;
            txtUbicacion.Text = "Nave";
            // 
            // txtComentarios
            // 
            txtComentarios.Font = new Font("Segoe UI Semibold", 12F);
            txtComentarios.Location = new Point(41, 243);
            txtComentarios.Name = "txtComentarios";
            txtComentarios.Size = new Size(209, 29);
            txtComentarios.TabIndex = 8;
            txtComentarios.Text = "Comentarios";
            // 
            // txtEncargado
            // 
            txtEncargado.Font = new Font("Segoe UI Semibold", 12F);
            txtEncargado.Location = new Point(41, 207);
            txtEncargado.Name = "txtEncargado";
            txtEncargado.Size = new Size(209, 29);
            txtEncargado.TabIndex = 10;
            txtEncargado.Text = "Nombre";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 18F);
            label7.ForeColor = Color.FromArgb(26, 26, 26);
            label7.Location = new Point(335, 10);
            label7.Name = "label7";
            label7.Size = new Size(301, 32);
            label7.TabIndex = 11;
            label7.Text = "ASIGNACIÓN DE EQUIPOS";
            label7.Click += label7_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(282, 94);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(439, 271);
            dataGridView1.TabIndex = 12;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pctureLogo);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(txtEncargado);
            panel1.Controls.Add(btnGuardarMovimiento);
            panel1.Controls.Add(txtComentarios);
            panel1.Controls.Add(txtId);
            panel1.Controls.Add(txtUbicacion);
            panel1.Location = new Point(190, 58);
            panel1.Name = "panel1";
            panel1.Size = new Size(761, 415);
            panel1.TabIndex = 13;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Excel2__1_1;
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 81);
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // pctureLogo
            // 
            pctureLogo.Location = new Point(642, 10);
            pctureLogo.Name = "pctureLogo";
            pctureLogo.Size = new Size(100, 50);
            pctureLogo.TabIndex = 13;
            pctureLogo.TabStop = false;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel2.Location = new Point(40, 479);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(911, 19);
            flowLayoutPanel2.TabIndex = 19;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(40, 36);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(911, 19);
            flowLayoutPanel1.TabIndex = 17;
            flowLayoutPanel1.Paint += flowLayoutPanel1_Paint;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.FromArgb(255, 128, 128);
            label1.Location = new Point(41, 119);
            label1.Name = "label1";
            label1.Size = new Size(182, 15);
            label1.TabIndex = 15;
            label1.Text = "Este dispositivo ya fue registrado!";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 115, 138);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 12F);
            button1.ForeColor = Color.FromArgb(248, 249, 250);
            button1.Location = new Point(41, 137);
            button1.Name = "button1";
            button1.Size = new Size(209, 29);
            button1.TabIndex = 16;
            button1.Text = "Reasignar";
            button1.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(40, 58);
            panel5.Name = "panel5";
            panel5.Size = new Size(144, 415);
            panel5.TabIndex = 30;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(17, 102);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(39, 61);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(25, 118, 210);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Image = Properties.Resources.logout_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnExit.Location = new Point(64, 330);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(64, 47);
            btnExit.TabIndex = 3;
            btnExit.UseVisualStyleBackColor = false;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(25, 118, 210);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderSize = 0;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Image = Properties.Resources.analytics_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnTracking.Location = new Point(64, 266);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(64, 47);
            btnTracking.TabIndex = 2;
            btnTracking.UseVisualStyleBackColor = false;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(25, 118, 210);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderSize = 0;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Image = Properties.Resources.table_edit_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnCrud.Location = new Point(64, 203);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(64, 47);
            btnCrud.TabIndex = 1;
            btnCrud.UseVisualStyleBackColor = false;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(25, 118, 210);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderSize = 0;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.ForeColor = Color.FromArgb(141, 122, 104);
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.Location = new Point(64, 143);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(64, 47);
            btnHome.TabIndex = 0;
            btnHome.UseVisualStyleBackColor = false;
            // 
            // Tracking
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(984, 541);
            Controls.Add(panel5);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(panel1);
            Controls.Add(label5);
            Controls.Add(label4);
            Name = "Tracking";
            Text = "Rastreo";
            Load += Tracking_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pctureLogo).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private Label label4;
        private Label label5;
        private Button btnGuardarMovimiento;
        private TextBox txtId;
        private ComboBox txtUbicacion;
        private TextBox txtComentarios;
        private TextBox txtEncargado;
        private Label label7;
        private DataGridView dataGridView1;
        private Panel panel1;
        private PictureBox pctureLogo;
        private FlowLayoutPanel flowLayoutPanel2;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox2;
        private Button button1;
        private Label label1;
        private Panel panel5;
        private Label label11;
        private Button btnProfil;
        private Button btnExit;
        private Button btnTracking;
        private Button btnCrud;
        private Button btnHome;
    }
}