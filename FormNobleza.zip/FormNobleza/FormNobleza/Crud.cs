﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FormNobleza
{
    public partial class Crud : Form
    {
        public Crud()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Crud_Load(object sender, EventArgs e)
        {


        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {

        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }
    }
}
