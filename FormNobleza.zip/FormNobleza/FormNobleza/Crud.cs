﻿using FormNobleza.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using FormNobleza.Models;

namespace FormNobleza
{
    public partial class Crud : Form
    {
        private readonly HardwareRepository _hardwareRepository = new HardwareRepository();

        private bool _esModoEdicion = false;
        private Hardware _equipoActual = null;
        public Crud()
        {
            InitializeComponent();
            ConfigurarInterfazInicial();
            txtNumeroSerie.KeyDown += txtNumeroSerie_KeyDown;
        }

        ///<summary>
        ///Establecemos el estado estático de los controles del formulario y bloque la edicion
        ///</summary>
        ///
        private void txtNumeroSerie_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            e.SuppressKeyPress = true; //Suprime el sonido 

            // Campo vacio 
            if (string.IsNullOrWhiteSpace(txtNumeroSerie.Text))
            {
                MessageBox.Show("Ingresa un numero se serie.", "Campo Vacío",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                // Consultamos si el numero se serie existe

                bool existe = _hardwareRepository.ExisteNumeroSerie(txtNumeroSerie.Text.Trim());

                if (existe)
                {
                    lblAlertaId.Text = "Numero de serie existente";
                    lblAlertaId.ForeColor= Color.Green;
                    lblAlertaId.Visible = true;

                    //Guardamos en memoria el quipo 
                    _equipoActual = HardwareRepository.BuscarPorNumeroSerie(serie);
                }
                else
                {
                    lblAlertaId.Text = "Numero de serie inexistente";
                    lblAlertaId.ForeColor = Color.Red;
                }
                lblAlertaId.Visible = true;
            }catch (Exception ex)
            {
                MessageBox.Show("Error al consultar:\n" + ex.Message, "Error",
            MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ConfigurarInterfazInicial()
        {
            //Restrriccion de botones
            btnEliminarEquipo.Enabled = false;
            btnAñadirEquipo.Enabled = false;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Crud_Load(object sender, EventArgs e)
        {


        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

            FormLogin pantallaDashboard = new FormLogin();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {
            
            
            }


        private void btnReportes_Click(object sender, EventArgs e)
        {
            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnBusqueda_Click(object sender, EventArgs e)
        {


        }

        private void txtRastreoId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRastreoId_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        

        private void txtNumeroSerie_TextChanged(object sender, EventArgs e)
        {

        }
    }
}