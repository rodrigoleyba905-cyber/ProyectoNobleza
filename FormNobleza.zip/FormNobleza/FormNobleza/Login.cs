namespace FormNobleza
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            // Clonamos la navegación directa para el Sprint
            Menu pantallaDashboard = new Menu();
                pantallaDashboard.Show();

                this.Hide(); // Oculta el login
            }
        

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
