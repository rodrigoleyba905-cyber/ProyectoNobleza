﻿namespace FormNobleza
{
    partial class Tracking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tracking));
            label4 = new Label();
            label5 = new Label();
            btnGuardarAsignacion = new Button();
            txtId = new TextBox();
            cmbUbicacion = new ComboBox();
            txtComentarios = new TextBox();
            txtEncargado = new TextBox();
            label7 = new Label();
            dataGridAsignacion = new DataGridView();
            panel1 = new Panel();
            txtIdTrabajador = new TextBox();
            pickerFecha = new DateTimePicker();
            btnReasignar = new Button();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            flowLayoutPanel2 = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            btnHome = new Button();
            btnCrud = new Button();
            btnTracking = new Button();
            btnExit = new Button();
            btnProfil = new Button();
            label11 = new Label();
            panel5 = new Panel();
            btnReportes = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridAsignacion).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(95, 323);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(380, 387);
            label5.Name = "label5";
            label5.Size = new Size(0, 15);
            label5.TabIndex = 4;
            // 
            // btnGuardarAsignacion
            // 
            btnGuardarAsignacion.BackColor = Color.FromArgb(0, 115, 138);
            btnGuardarAsignacion.Cursor = Cursors.Hand;
            btnGuardarAsignacion.Enabled = false;
            btnGuardarAsignacion.FlatAppearance.BorderSize = 0;
            btnGuardarAsignacion.FlatStyle = FlatStyle.Flat;
            btnGuardarAsignacion.Font = new Font("Segoe UI Semibold", 12F);
            btnGuardarAsignacion.ForeColor = Color.FromArgb(248, 249, 250);
            btnGuardarAsignacion.Location = new Point(41, 362);
            btnGuardarAsignacion.Name = "btnGuardarAsignacion";
            btnGuardarAsignacion.Size = new Size(209, 29);
            btnGuardarAsignacion.TabIndex = 5;
            btnGuardarAsignacion.Text = "Guardar";
            btnGuardarAsignacion.UseVisualStyleBackColor = false;
            // 
            // txtId
            // 
            txtId.BorderStyle = BorderStyle.None;
            txtId.Cursor = Cursors.IBeam;
            txtId.Font = new Font("Segoe UI Semibold", 12F);
            txtId.Location = new Point(41, 94);
            txtId.Name = "txtId";
            txtId.PlaceholderText = "Id:";
            txtId.Size = new Size(209, 22);
            txtId.TabIndex = 6;
            // 
            // cmbUbicacion
            // 
            cmbUbicacion.Cursor = Cursors.Hand;
            cmbUbicacion.Enabled = false;
            cmbUbicacion.FlatStyle = FlatStyle.Flat;
            cmbUbicacion.Font = new Font("Segoe UI Semibold", 12F);
            cmbUbicacion.FormattingEnabled = true;
            cmbUbicacion.Items.AddRange(new object[] { "Nave 1", "Nave 2", "Nave 3", "Nave 4", "Nave 5", "Nave 6", "Nave 7", "Nave 8", "Nave 9", "Nave 10", "Nave 11", "Nave 12", "", "" });
            cmbUbicacion.Location = new Point(41, 172);
            cmbUbicacion.Name = "cmbUbicacion";
            cmbUbicacion.Size = new Size(209, 29);
            cmbUbicacion.TabIndex = 7;
            cmbUbicacion.Text = "Nave";
            cmbUbicacion.SelectedIndexChanged += txtUbicacion_SelectedIndexChanged;
            // 
            // txtComentarios
            // 
            txtComentarios.BorderStyle = BorderStyle.None;
            txtComentarios.Cursor = Cursors.IBeam;
            txtComentarios.Enabled = false;
            txtComentarios.Font = new Font("Segoe UI Semibold", 12F);
            txtComentarios.Location = new Point(41, 279);
            txtComentarios.Name = "txtComentarios";
            txtComentarios.PlaceholderText = "Comentarios:";
            txtComentarios.Size = new Size(209, 22);
            txtComentarios.TabIndex = 8;
            // 
            // txtEncargado
            // 
            txtEncargado.BorderStyle = BorderStyle.None;
            txtEncargado.Cursor = Cursors.IBeam;
            txtEncargado.Enabled = false;
            txtEncargado.Font = new Font("Segoe UI Semibold", 12F);
            txtEncargado.Location = new Point(41, 243);
            txtEncargado.Name = "txtEncargado";
            txtEncargado.PlaceholderText = "Nombre:";
            txtEncargado.Size = new Size(209, 22);
            txtEncargado.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 18F);
            label7.ForeColor = Color.FromArgb(26, 26, 26);
            label7.Location = new Point(335, 10);
            label7.Name = "label7";
            label7.Size = new Size(301, 32);
            label7.TabIndex = 11;
            label7.Text = "ASIGNACIÓN DE EQUIPOS";
            label7.Click += label7_Click;
            // 
            // dataGridAsignacion
            // 
            dataGridAsignacion.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridAsignacion.Location = new Point(282, 94);
            dataGridAsignacion.Name = "dataGridAsignacion";
            dataGridAsignacion.Size = new Size(439, 271);
            dataGridAsignacion.TabIndex = 12;
            dataGridAsignacion.CellContentClick += dataGridView1_CellContentClick;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(248, 249, 250);
            panel1.Controls.Add(txtIdTrabajador);
            panel1.Controls.Add(pickerFecha);
            panel1.Controls.Add(btnReasignar);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(dataGridAsignacion);
            panel1.Controls.Add(txtEncargado);
            panel1.Controls.Add(btnGuardarAsignacion);
            panel1.Controls.Add(txtComentarios);
            panel1.Controls.Add(txtId);
            panel1.Controls.Add(cmbUbicacion);
            panel1.Location = new Point(190, 58);
            panel1.Name = "panel1";
            panel1.Size = new Size(761, 415);
            panel1.TabIndex = 13;
            // 
            // txtIdTrabajador
            // 
            txtIdTrabajador.BorderStyle = BorderStyle.None;
            txtIdTrabajador.Cursor = Cursors.IBeam;
            txtIdTrabajador.Font = new Font("Segoe UI Semibold", 12F);
            txtIdTrabajador.Location = new Point(41, 207);
            txtIdTrabajador.Name = "txtIdTrabajador";
            txtIdTrabajador.PlaceholderText = "Id Trabajador:";
            txtIdTrabajador.Size = new Size(209, 22);
            txtIdTrabajador.TabIndex = 18;
            // 
            // pickerFecha
            // 
            pickerFecha.CalendarFont = new Font("Segoe UI Semibold", 12F);
            pickerFecha.Cursor = Cursors.Hand;
            pickerFecha.Enabled = false;
            pickerFecha.Font = new Font("Segoe UI Semibold", 12F);
            pickerFecha.Location = new Point(41, 311);
            pickerFecha.Name = "pickerFecha";
            pickerFecha.Size = new Size(209, 29);
            pickerFecha.TabIndex = 17;
            // 
            // btnReasignar
            // 
            btnReasignar.BackColor = Color.FromArgb(0, 115, 138);
            btnReasignar.Cursor = Cursors.Hand;
            btnReasignar.FlatAppearance.BorderSize = 0;
            btnReasignar.FlatStyle = FlatStyle.Flat;
            btnReasignar.Font = new Font("Segoe UI Semibold", 12F);
            btnReasignar.ForeColor = Color.FromArgb(248, 249, 250);
            btnReasignar.Location = new Point(41, 137);
            btnReasignar.Name = "btnReasignar";
            btnReasignar.Size = new Size(209, 29);
            btnReasignar.TabIndex = 16;
            btnReasignar.Text = "Reasignar";
            btnReasignar.UseVisualStyleBackColor = false;
            btnReasignar.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.FromArgb(255, 128, 128);
            label1.Location = new Point(41, 119);
            label1.Name = "label1";
            label1.Size = new Size(182, 15);
            label1.TabIndex = 15;
            label1.Text = "Este dispositivo ya fue registrado!";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Excel2__1_1;
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 81);
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel2.Location = new Point(40, 479);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(911, 19);
            flowLayoutPanel2.TabIndex = 19;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(0, 115, 138);
            flowLayoutPanel1.Location = new Point(40, 36);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(911, 19);
            flowLayoutPanel1.TabIndex = 17;
            flowLayoutPanel1.Paint += flowLayoutPanel1_Paint;
            // 
            // btnHome
            // 
            btnHome.BackColor = Color.FromArgb(25, 118, 210);
            btnHome.Cursor = Cursors.Hand;
            btnHome.FlatAppearance.BorderSize = 0;
            btnHome.FlatStyle = FlatStyle.Flat;
            btnHome.ForeColor = Color.FromArgb(141, 122, 104);
            btnHome.Image = (Image)resources.GetObject("btnHome.Image");
            btnHome.Location = new Point(64, 94);
            btnHome.Name = "btnHome";
            btnHome.Size = new Size(64, 47);
            btnHome.TabIndex = 0;
            btnHome.UseVisualStyleBackColor = false;
            btnHome.Click += btnHome_Click;
            // 
            // btnCrud
            // 
            btnCrud.BackColor = Color.FromArgb(25, 118, 210);
            btnCrud.Cursor = Cursors.Hand;
            btnCrud.FlatAppearance.BorderSize = 0;
            btnCrud.FlatStyle = FlatStyle.Flat;
            btnCrud.Image = Properties.Resources.table_edit_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnCrud.Location = new Point(64, 147);
            btnCrud.Name = "btnCrud";
            btnCrud.Size = new Size(64, 47);
            btnCrud.TabIndex = 1;
            btnCrud.UseVisualStyleBackColor = false;
            btnCrud.Click += btnCrud_Click;
            // 
            // btnTracking
            // 
            btnTracking.BackColor = Color.FromArgb(25, 118, 210);
            btnTracking.Cursor = Cursors.Hand;
            btnTracking.FlatAppearance.BorderSize = 0;
            btnTracking.FlatStyle = FlatStyle.Flat;
            btnTracking.Image = Properties.Resources.analytics_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnTracking.Location = new Point(64, 200);
            btnTracking.Name = "btnTracking";
            btnTracking.Size = new Size(64, 47);
            btnTracking.TabIndex = 2;
            btnTracking.UseVisualStyleBackColor = false;
            btnTracking.Click += btnTracking_Click;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.FromArgb(25, 118, 210);
            btnExit.Cursor = Cursors.Hand;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Image = Properties.Resources.logout_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnExit.Location = new Point(64, 306);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(64, 47);
            btnExit.TabIndex = 3;
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnProfil
            // 
            btnProfil.Cursor = Cursors.Hand;
            btnProfil.FlatAppearance.BorderSize = 0;
            btnProfil.FlatStyle = FlatStyle.Flat;
            btnProfil.Image = Properties.Resources.person_40dp_1F1F1F_FILL0_wght400_GRAD0_opsz40;
            btnProfil.Location = new Point(44, 23);
            btnProfil.Name = "btnProfil";
            btnProfil.Size = new Size(64, 38);
            btnProfil.TabIndex = 10;
            btnProfil.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(22, 64);
            label11.Name = "label11";
            label11.Size = new Size(111, 15);
            label11.TabIndex = 6;
            label11.Text = "¡HOLA, INGENIERO!";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(248, 249, 250);
            panel5.Controls.Add(btnReportes);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(btnProfil);
            panel5.Controls.Add(btnExit);
            panel5.Controls.Add(btnTracking);
            panel5.Controls.Add(btnCrud);
            panel5.Controls.Add(btnHome);
            panel5.Location = new Point(40, 58);
            panel5.Name = "panel5";
            panel5.Size = new Size(144, 415);
            panel5.TabIndex = 30;
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.FromArgb(25, 118, 210);
            btnReportes.Cursor = Cursors.Hand;
            btnReportes.FlatAppearance.BorderSize = 0;
            btnReportes.FlatStyle = FlatStyle.Flat;
            btnReportes.ForeColor = Color.FromArgb(141, 122, 104);
            btnReportes.Image = (Image)resources.GetObject("btnReportes.Image");
            btnReportes.Location = new Point(64, 253);
            btnReportes.Name = "btnReportes";
            btnReportes.Size = new Size(64, 47);
            btnReportes.TabIndex = 12;
            btnReportes.UseVisualStyleBackColor = false;
            btnReportes.Click += btnReportes_Click;
            // 
            // Tracking
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(984, 541);
            Controls.Add(panel5);
            Controls.Add(flowLayoutPanel2);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(panel1);
            Controls.Add(label5);
            Controls.Add(label4);
            Name = "Tracking";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Rastreo";
            Load += Tracking_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridAsignacion).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion
        private Label label4;
        private Label label5;
        private Button btnGuardarAsignacion;
        private TextBox txtId;
        private ComboBox cmbUbicacion;
        private TextBox txtComentarios;
        private TextBox txtEncargado;
        private Label label7;
        private DataGridView dataGridAsignacion;
        private Panel panel1;
        private FlowLayoutPanel flowLayoutPanel2;
        private FlowLayoutPanel flowLayoutPanel1;
        private PictureBox pictureBox2;
        private Button btnReasignar;
        private Label label1;
        private DateTimePicker pickerFecha;
        private Button btnHome;
        private Button btnCrud;
        private Button btnTracking;
        private Button btnExit;
        private Button btnProfil;
        private Label label11;
        private Panel panel5;
        private Button btnReportes;
        private TextBox txtIdTrabajador;
    }
}