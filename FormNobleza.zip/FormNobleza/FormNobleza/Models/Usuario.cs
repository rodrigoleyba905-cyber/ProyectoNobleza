﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormNobleza.Models
{
    public class Usuario
    {
        public int IdUsuario { get; set; }
        public string nombreUsuario { get; set; }
        public string passwordHash { get; set; }
    }
}
