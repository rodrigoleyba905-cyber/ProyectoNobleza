﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormNobleza.Models
{
    public class Hardware
    {
        public int idHardware {  get; set; }
        public string numeroSerie { get; set; }
        public string modelo { get; set; }
        public int idCategoria { get; set; }
        public int idMarca { get; set; }
        public int idEstado { get; set; }
        public int creadoPor { get; set; }
        public int actualizadoPor { get; set; }
        public DateTime fecha { get; set; }

    }
}
