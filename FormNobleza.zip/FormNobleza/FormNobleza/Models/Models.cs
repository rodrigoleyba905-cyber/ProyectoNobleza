﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormNobleza.Models
{
    public static class UsuarioSesion
    {
        // Propiedades estáticas que retienen su valor en el cambio de contextos (Forms)
        public static int IdUsuario { get; set; }
        public static string NombreUsuario { get; set; }
    }
}

