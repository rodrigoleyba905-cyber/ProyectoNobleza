﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FormNobleza
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtRastreo_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void principalMenu_Load(object sender, EventArgs e)
        {

        }

        private void btnCrud_Click(object sender, EventArgs e)
        {

            Crud pantallaDashboard = new Crud();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnHome_Click(object sender, EventArgs e)
        {

            Menu pantallaDashboard = new Menu();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnTracking_Click(object sender, EventArgs e)
        {

            Tracking pantallaDashboard = new Tracking();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            {

                FormLogin pantallaDashboard = new FormLogin();
                pantallaDashboard.Show();

                this.Hide(); // Oculta el login
            }
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {

            Reportes pantallaDashboard = new Reportes();
            pantallaDashboard.Show();

            this.Hide(); // Oculta el login
        }

        private void txtRastreoId_KeyDown(object sender, KeyEventArgs e)
        {   
            //La tecla presionada fue ENTER?
            if (e.KeyCode == Keys.Enter)
            { 
                
                e.SuppressKeyPress = true; //Sonido suprimido
                btnBusqueda_Click(this, new EventArgs()); //Evento del boton original
            }
        }

        private void btnBusqueda_Click(object sender, EventArgs e)
        {

        }
    }
}
