﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using FormNobleza.Models;

namespace FormNobleza.Data
{
    // Hereda ConnectionToSql para reutilizar GetConnection()
    public class HardwareRepository : ConnectionToSql
    {
      //VALIDAR ID

        public bool ExisteNumeroSerie(string serie)
        {
            string query = "SELECT COUNT (*) FROM hardware WHERE numeroSerie = @numeroSerie;";
            string numeroSerie = serie.Trim();

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", numeroSerie);

                        //Regresamos el primer valor a la fila
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        return count > 0;

                    }
                }
            } catch (Exception ex)
            {
                throw new Exception("Error al validar el ID: " + ex.Message);
            }
        }

        //Buscamos por numero de serie

        //Devuleve el objeto para pintar el panel
        //Devuelve null si no existe

        public Hardware BuscarPorNumeroSerie(string serie)
        {
            string valorSerie= serie.Trim();
            string query = "SELECT * FROM hardware WHERE numeroSerie = @numeroSerie;";

            try
            {
                using (var connection = GetConnection())
                {
                    connection.Open();
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeroSerie", valorSerie);

                        using(var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                //Mapeamos todo en los objetos del crud

                                return new Hardware
                                {
                                    idHardware = Convert.ToInt32(reader["idHardware"]),
                                    numeroSerie = reader["numeroSerie"].ToString(),
                                    modelo = reader["modelo"].ToString(),
                                    idCategoria = Convert.ToInt32(reader["isCategoria"]),
                                    idMarca = Convert.ToInt32(reader["idMarca"]),
                                    idEstado = Convert.ToInt32(reader["idEstado"]),
                                    creadoPor = Convert.ToInt32(reader["creadoPor"]),
                                    actualizadoPor= reader["actualizadoPor"] ==DBNull.Value ?0 :Convert.ToInt32(reader["actualizadoPor"])


                                };

                            }
                        }

                    }
                        
                    
                } return null;
            } catch (Exception ex)
            {
                throw new Exception("Error al buscar por numero de Serie " + ex.Message);
            }
        }
    }
}