﻿using DataAccess;
namespace ClaseDominio
{
    public class UserModel
    {
        UserData UserData = new UserData();
        public bool LoginUser (string user, string pass)
        {
            return UserData.Login(user, pass);
        }   
        

        }
    }

